Upload index.html and the entire assets folder to the root of your GitHub repository.
Replace the placeholder email address in index.html before publishing.
